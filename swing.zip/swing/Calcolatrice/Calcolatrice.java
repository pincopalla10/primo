package Calcolatrice;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Calcolatrice extends JFrame {
    private JTextField testo;
    private JButton[] cifre;
    private JButton piu;
    private JButton meno;
    private JButton uguale;
    private JButton per;
    private JButton diviso;
    private JButton ce;

    private ArrayList<Integer> valori;
    private int operazioneCorrente;
    private boolean nuovoValore;

    /**
     * costruttore senza parametri
     * crea una finestra per testare i componenti più comuni
     */
    public Calcolatrice() {
        setSize(300, 400);
        setTitle("Calcolatrice");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        testo = new JTextField("");
        testo.setHorizontalAlignment(JTextField.RIGHT);
        testo.setEditable(false);
        GestoreScelta gestore = new Calcolatrice.GestoreScelta();

        cifre = new JButton[10];
        for (int i = 0; i < 10; i++) {
            cifre[i] = new JButton("" + i);
            cifre[i].addActionListener(gestore);
        } // for
        piu = new JButton("+");
        meno = new JButton("-");
        per = new JButton("*");
        uguale = new JButton("=");
        ce = new JButton("CE");
        diviso = new JButton(":");

        piu.addActionListener(gestore);
        meno.addActionListener(gestore);
        per.addActionListener(gestore);
        diviso.addActionListener(gestore);
        uguale.addActionListener(gestore);
        ce.addActionListener(gestore);

        JPanel pannello2 = new JPanel();
        pannello2.setLayout(new GridLayout(4, 4));
        pannello2.add(cifre[1]);
        pannello2.add(cifre[2]);
        pannello2.add(cifre[3]);
        pannello2.add(ce);
        pannello2.add(cifre[4]);
        pannello2.add(cifre[5]);
        pannello2.add(cifre[6]);
        pannello2.add(piu);
        pannello2.add(cifre[7]);
        pannello2.add(cifre[8]);
        pannello2.add(cifre[9]);
        pannello2.add(meno);
        pannello2.add(per);
        pannello2.add(cifre[0]);
        pannello2.add(diviso);
        pannello2.add(uguale);

        add(testo, "North");

        add(pannello2, "Center");

        setVisible(true);
        valori = new ArrayList<>();
        operazioneCorrente = 0;
        nuovoValore = true;
    }// Calcolatrice

    /** classe interna, ascoltatore di tipo ActionListener */
    private class GestoreScelta implements ActionListener {

        public void actionPerformed(ActionEvent event) {
            String tasto = event.getActionCommand();

            double valTasto = isDouble(tasto);
            if (valTasto != -1) {
                if (nuovoValore) {
                    testo.setText("");
                    nuovoValore = false;
                } // if
                testo.setText(testo.getText() + tasto);
            } // if

            switch (tasto) {
                case "+":
                    aggiungiValore();
                    operazioneCorrente = 1;
                    break;
                case "-":
                    aggiungiValore();
                    operazioneCorrente = 2;
                    break;
                case "*":
                    aggiungiValore();
                    operazioneCorrente = 3;
                    break;
                case ":":
                    aggiungiValore();
                    operazioneCorrente = 4;
                    break;
                case "CE":
                    valori.clear();
                    operazioneCorrente = 0;
                    testo.setText("");
                    nuovoValore = true;
                    break;
                case "=":
                    aggiungiValore();
                    double risultato = calcola();
                    testo.setText("" + risultato);
                    valori.clear();
                    valori.add((int) risultato);
                    nuovoValore = true;
                    break;
            }// switch

        }// actionPerformed

        /**
         * Verifica se una stringa è un numero decimale.
         * 
         * @return -1 se non lo è altrimenti il suo valore
         */
        private double isDouble(String num) {
            try {
                double n = Double.parseDouble(num);
                return n;
            } catch (Exception e) {
                return -1;
            } // try-catch
        }// isDouble

        /**
         * Aggiunge il valore corrente alla lista dei valori inseriti dall'utente.
         */
        private void aggiungiValore() {
            if (!testo.getText().isEmpty()) {
                double valoreCorrente = Double.parseDouble(testo.getText());
                valori.add((int) valoreCorrente);
                nuovoValore = true;
            } // if
        }// aggiungiValore

        /**
         * Calcola il risultato dell'operazione corrente sui valori nella lista.
         * 
         * @return il risultato del calcolo
         */
        private double calcola() {
            double risultato = valori.get(0);
            for (int i = 1; i < valori.size(); i++) {
                double valoreCorrente = valori.get(i);
                switch (operazioneCorrente) {
                    case 1:
                        risultato += valoreCorrente;
                        break;
                    case 2:
                        risultato -= valoreCorrente;
                        break;
                    case 3:
                        risultato *= valoreCorrente;
                        break;
                    case 4:
                        risultato /= valoreCorrente;
                        break;
                }// switch
            } // for
            return risultato;
        }// ccalcola

    }// GestoreScelta

    public static void main(String[] args) {
        new Calcolatrice();
    }// main
}// Calcolatrice