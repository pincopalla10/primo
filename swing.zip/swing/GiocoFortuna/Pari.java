package GiocoFortuna;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class Pari extends JFrame {

    private static final int MAX_NUM_GIOCATE = 10;
    private int numGiocate = 0;
    private boolean isGiocando = false;
    private boolean isPari = false;

    JLabel pari, dispari, risultato;
    JRadioButton pariButton, dispariButton;
    JButton avvio;
    JPanel panel;

    public Pari() {

        setTitle("Gioco di fortuna");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        setLayout(new BorderLayout());

        /* radio button Pari e radio button dispari */
        JPanel panel1 = new JPanel();
        ButtonGroup gruppo = new ButtonGroup();
        pari = new JLabel("Pari ");
        pariButton = new JRadioButton();
        gruppo.add(pariButton);
        panel1.add(pari);
        panel1.add(pariButton);

        dispari = new JLabel("Dispari ");
        dispariButton = new JRadioButton();
        gruppo.add(dispariButton);
        panel1.add(dispari);
        panel1.add(dispariButton);

        /* pulsante avvio gioco */
        avvio = new JButton("Avvia");
        avvio.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (e.getActionCommand().equals("Avvia")) {
                    isGiocando = true;
                    numGiocate = 0;
                    risultato.setText("");
                    panel.setBackground(Color.WHITE);
                }
            }
        });
        panel1.add(avvio);

        add(panel1, BorderLayout.NORTH);

        /* area dove fare click */
        panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (isGiocando && numGiocate < MAX_NUM_GIOCATE) {
                    Point point = evt.getPoint();
                    int x = point.x;
                    int y = point.y;
                    Random rand = new Random();
                    int sum = x + y + rand.nextInt(11);
                    isPari = sum % 2 == 0;
                    risultato.setText(isPari ? "Pari" : "Dispari");
                    panel.setBackground(isPari ? Color.GREEN : Color.RED);
                    numGiocate++;
                    if (numGiocate >= MAX_NUM_GIOCATE) {
                        isGiocando = false;
                    }
                }
            }
        });

        JLabel label = new JLabel("FAI CLIC SULLO SCHERMO");
        panel.add(label);
        add(panel, BorderLayout.CENTER);

        /* risultato */
        JPanel panel2 = new JPanel();
        JLabel label2 = new JLabel("Risultato: ");
        panel2.add(label2);
        risultato = new JLabel("");
        panel2.add(risultato);
        add(panel2, BorderLayout.SOUTH);
    }

    public static void main(String[] args) {
        new Pari();
    }
}