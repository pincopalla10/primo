package GiocoFortuna;

public class PariTest {
    public static void main(String[] args) {
        Pari p = new Pari();
    }
}
