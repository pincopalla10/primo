package ConveritoreGradi;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class ConvertitoreGradi extends JFrame implements ActionListener {

    JTextField temperaturaC, temperaturaF;

    public ConvertitoreGradi() {

        setTitle("Convertitore °C o °F");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 1));

        /* temperatura (°C) + bottone converti °C a °F */
        JPanel panel1 = new JPanel();
        JLabel temperaturLabel1 = new JLabel("temperatura(°C) ", SwingConstants.LEFT);
        panel1.add(temperaturLabel1);
        add(panel1);
        JPanel panel2 = new JPanel();
        temperaturaC = new JTextField(15);
        panel2.add(temperaturaC);
        JButton button1 = new JButton("Converti °C a °F");
        button1.setActionCommand("ConvertiCelsius");
        button1.addActionListener(this);
        panel2.add(button1);
        add(panel2);

        /* temperatura (°F) + bottone converti °F a °C */
        JPanel panel3 = new JPanel();
        JLabel temperaturLabel2 = new JLabel("temperatura(°F) ", SwingConstants.LEFT);
        panel3.add(temperaturLabel2);
        add(panel3);
        JPanel panel4 = new JPanel();
        temperaturaF = new JTextField(15);
        panel4.add(temperaturaF);
        JButton button2 = new JButton("Converti °F a °C");
        button2.setActionCommand("ConvertiFahrenheit");
        button2.addActionListener(this);
        panel4.add(button2);
        add(panel4);

        setVisible(true);

    }

    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("ConvertiCelsius")) {
            try {
                double temperaturaCelsius = Double.parseDouble(temperaturaC.getText());
                double conversione = (temperaturaCelsius * 1.8) + 32;
                temperaturaF.setText(String.format("%.2f", conversione));
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this,
                        "Inserire un valore numerico valido per la temperatura in gradi Celsius.", "Errore",
                        JOptionPane.ERROR_MESSAGE);
            }
        } else if (e.getActionCommand().equals("ConvertiFahrenheit")) {
            try {
                double temperaturaFahrenheit = Double.parseDouble(temperaturaF.getText());
                double conversione = (temperaturaFahrenheit - 32) / 1.8;
                temperaturaC.setText(String.format("%.2f", conversione));
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this,
                        "Inserire un valore numerico valido per la temperatura in gradi Fahrenheit.", "Errore",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        new ConvertitoreGradi();
    }

}
