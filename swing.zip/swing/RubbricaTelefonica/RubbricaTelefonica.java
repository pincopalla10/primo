package RubbricaTelefonica;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;

public class RubbricaTelefonica extends JFrame implements ActionListener {

    private JTextField nomeField, cognomeField, numeroField;
    private ArrayList<String> rubrica;

    public RubbricaTelefonica() {

        setTitle("Rubbrica Telefonica");
        setSize(300, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(5, 1));

        /* nome */
        JPanel panel1 = new JPanel();
        JLabel nome = new JLabel("Nome ");
        nomeField = new JTextField(15);
        panel1.add(nome);
        panel1.add(nomeField);
        add(panel1);

        /* cognome */
        JPanel panel2 = new JPanel();
        JLabel cognome = new JLabel("Cognome ");
        cognomeField = new JTextField(15);
        panel2.add(cognome);
        panel2.add(cognomeField);
        add(panel2);

        /* numero di telefono */
        JPanel panel3 = new JPanel();
        JLabel numero = new JLabel("Numero ");
        numeroField = new JTextField(15);
        panel3.add(numero);
        panel3.add(numeroField);
        add(panel3);

        /* bottone aggiungi contatto */
        JPanel panel4 = new JPanel();
        JButton button1 = new JButton("Aggiungi Contatto");
        button1.addActionListener(this);
        panel4.add(button1);
        add(panel4);

        /* bottone visualizza rubrica */
        JPanel panel5 = new JPanel();
        JButton button2 = new JButton("Visualizza Rubrica");
        button2.addActionListener(this);
        panel5.add(button2);
        add(panel5);

        rubrica = new ArrayList<String>();

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("Aggiungi Contatto")) { // controlla quale bottone è stato premuto, se è stato
                                                                // premunto quello di "aggiungi contatto" fa le seguenti
                                                                // operazioni se no passa aventi
            String nome = nomeField.getText(); // salva il valore inserito da tastiera
            String cognome = cognomeField.getText(); // salva il valore inserito da tastiera
            String numero = numeroField.getText(); // salva il valore inserito da tastiera
            rubrica.add(nome + " " + cognome + ": " + numero); // aggiunge il contatto a rubrica
            JOptionPane.showMessageDialog(this, "Contatto aggiunto alla rubrica"); // messaggio di conferma
                                                                                   // dell'inserimento
            nomeField.setText(""); // svuota la cella di testo
            cognomeField.setText(""); // svuota la cella di testo
            numeroField.setText(""); // svuota la cella di testo
        } else if (e.getActionCommand().equals("Visualizza Rubrica")) { // controlla quale bottone è stato premuto, se è
                                                                        // stato premunto quello di "visualizza rubrica"
            if (rubrica.isEmpty()) { // controlla se rubbrica è vuota
                JOptionPane.showMessageDialog(this, "La rubrica è vuota"); // in questo caso verà visualizzato un
                                                                           // messaggio con scritto "la rubrica è vuota"
            } else {
                StringBuilder sb = new StringBuilder();
                for (String contatto : rubrica) {
                    sb.append(contatto);
                    sb.append("\n");
                }
                JOptionPane.showMessageDialog(this, sb.toString());
            }
        }
    }

    public static void main(String[] args) {
        new RubbricaTelefonica();
    }
}
