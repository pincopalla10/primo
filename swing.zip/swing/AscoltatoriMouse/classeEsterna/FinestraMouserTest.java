
public class FinestraMouserTest{

	public static void main(String[] args){
		FinestraMouse miaF=new FinestraMouse("Situazione iniziale");
	}//main

}//FinestraMouserTest
