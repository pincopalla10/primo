import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JPanel;



public class FinestraMouse extends JFrame{
	private JLabel m;
	
	/**crea una finestra con un messaggio iniziale
	 * @param mm messaggio iniziale*/
	public FinestraMouse(String mm){
		super("Eventi del mouse");
		setSize(400,400);
		m=new JLabel(mm);
		m.setFont(new Font("SansSerif",0,20));
		add(m,"Center");
		JLabel sud=new JLabel("cosa scrivo dentro");
		JLabel ll=new JLabel("processo");
		JPanel pan=new JPanel();
		addMouseListener(new AscoltatoreMouse(m)); //l'ascoltatore è estrno appunto AscoltatoreMouse
		pan.add(ll);
		pan.add(sud);
		add(pan,"South");
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}//FinestraMouse
	
	


}//FinestraMouse
