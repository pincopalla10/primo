import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;

 
 public class AscoltatoreMouse implements MouseListener{
	 
	 private JLabel m;
	 
	 
	 /**costruttore parametrico
	  * @param m etichetta che sarà la stessa del campo di FinestraMouse*/
	 public AscoltatoreMouse(JLabel m){
		 this.m = m;
	 }//AscoltatoreMouse
		 
		 public void mouseClicked(MouseEvent e){
			 m.setText("Hai cliccato in "+e.getX()+","+e.getY());
		 }//mouseClicked
		 
		 public void mouseReleased(MouseEvent e){
			 
		 }//mouseReleased
		 
		 public void mouseExited(MouseEvent e){
			 m.setText("Sei uscito dall'area della finestra");
		 }//mouseExited
		 
		 public void mousePressed(MouseEvent e){
			 
		 }//mousePressed
		 
		 public void mouseEntered(MouseEvent e){
			 m.setText("Sei appena entrato nell'area giusta");
		 }//mouseEntered
		 
	 }//AscoltatoreMouse
