import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JPanel;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;



public class FinestraMouse extends JFrame implements MouseListener {
	private JLabel m;
	
	/**crea una finestra con un messaggio iniziale
	 * @param mm messaggio iniziale*/
	public FinestraMouse(String mm){
		super("Eventi del mouse");
		setSize(400,400);
		m=new JLabel(mm);
		m.setFont(new Font("SansSerif",0,20));
		add(m,"Center");
		JLabel sud=new JLabel("cosa scrivo dentro");
		JLabel ll=new JLabel("processo");
		JPanel pan=new JPanel();
		addMouseListener(this); //l'ascoltatore in questo caso è FinestraMouse quindi definita come this 
		pan.add(ll);
		pan.add(sud);
		add(pan,"South");
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}//FinestraMouse
	
	
		 
		 public void mouseClicked(MouseEvent e){
			 m.setText("Hai cliccato in "+e.getX()+","+e.getY());
		 }//mouseClicked
		 
		 public void mouseReleased(MouseEvent e){
			 
		 }//mouseReleased
		 
		 public void mouseExited(MouseEvent e){
			 m.setText("Sei uscito dall'area della finestra");
		 }//mouseExited
		 
		 public void mousePressed(MouseEvent e){
			 
		 }//mousePressed
		 
		 public void mouseEntered(MouseEvent e){
			 m.setText("Sei appena entrato nell'area giusta");
		 }//mouseEntered
		 
	


}//FinestraMouse
