package Conversioni;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Conv extends JFrame implements ActionListener{
    
    JComboBox<String> lista; 
    JTextField textField;
    JRadioButton button1, button2, button3;
    JButton avvia;
    JTextField risuField;

    public Conv() {
        
        setTitle("Conversioni!");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        setLayout(new GridLayout(6, 1));

        /* titolo */
        JPanel panel1 = new JPanel();
        JLabel titolo = new JLabel("Converitore");
        panel1.add(titolo);
        add(panel1);

        /* lista */
        JPanel panel2 = new JPanel();
        JLabel label1 = new JLabel("Unita' di misura INIZIALE: ");
        lista = new JComboBox<String>();
        lista.addItem("millilitri");
        lista.addItem("centilitri");
        lista.addItem("litri");
        panel2.add(label1);
        panel2.add(lista);
        add(panel2);

        /* valore */
        JPanel panel3 = new JPanel();
        JLabel label2 = new JLabel("Valore della misura: ");
        panel3.add(label2);
        textField = new JTextField(15);
        panel3.add(textField);
        add(panel3);

        /* unita misura finale */
        JPanel panel4 = new JPanel();
        JLabel label3 = new JLabel("Unita' di misura FINALE: ");
        panel4.add(label3);
        ButtonGroup gruppo = new ButtonGroup();
        button1 = new JRadioButton("Centimetri cubi");
        button2 = new JRadioButton("Decimetri cubi");
        button3 = new JRadioButton("Metri cubi");
        gruppo.add(button1);
        gruppo.add(button2);
        gruppo.add(button3);
        panel4.add(button1);
        panel4.add(button2);
        panel4.add(button3);
        add(panel4);

        /* bottone avvia */
        JPanel panel5 = new JPanel();
        avvia = new JButton("Avvia");
        avvia.addActionListener(this);
        panel5.add(avvia);
        add(panel5);

        /* risultato */
        JPanel panle6 = new JPanel();
        JLabel label4 = new JLabel("Valore convertito: ");
        panle6.add(label4);
        risuField = new JTextField(15);
        risuField.setEditable(false);
        panle6.add(risuField);
        add(panle6);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getActionCommand().equals("Avvia")){
            String dati = textField.getText();
            String unita = (String) lista.getSelectedItem();
            double risultato = 0;

            if(button1.isSelected()){

                if(unita.equals("millilitri")){
                    risultato = Double.parseDouble(dati)*1;
                }else if(unita.equals("centilitri")){
                    risultato = Double.parseDouble(dati)*10;
                }else if(unita.equals("litri")){
                    risultato = Double.parseDouble(dati)*1000;
				}
			}else if(button2.isSelected()){
				if(unita.equals("millilitri")){
					risultato = Double.parseDouble(dati)/1000;
				}else if(unita.equals("centilitri")){
					risultato = Double.parseDouble(dati)/100;
				}else if(unita.equals("litri")){
					risultato = Double.parseDouble(dati)*100;
				}
			}else if(button3.isSelected()){

				if(unita.equals("millilitri")){
					risultato = Double.parseDouble(dati)/1000000;
				}else if(unita.equals("centilitri")){
					risultato = Double.parseDouble(dati)/100000;
				}else if(unita.equals("litri")){
					risultato = Double.parseDouble(dati)/1000;
				}
			}

			risuField.setText("" + risultato);
		}

	}
	public static void main(String[] args) {
		new Conv();
	}
	}
