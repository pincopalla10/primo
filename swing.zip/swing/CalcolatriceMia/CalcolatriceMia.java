package CalcolatriceMia;

import java.awt.*;
import javax.swing.*;

public class CalcolatriceMia extends JFrame {

    JButton uno, due, tre, quattro, cinque, sei, sette, otto, nove, zero, piu, meno, per, diviso, CE, uguale;
    JTextField area;

    public CalcolatriceMia() {

        setTitle("Calcolatrice mia");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(2, 1));

        /* schermo calcolatrice */
        JPanel panel1 = new JPanel();
        area = new JTextField(30);
        area.setHorizontalAlignment(JTextField.RIGHT);
        area.setEditable(false);
        panel1.add(area);
        add(panel1);

        /* pusantiera calcolatrice */
        JPanel panel2 = new JPanel();
        panel2.setLayout(new GridLayout(4, 4));
        uno = new JButton("1");
        due = new JButton("2");
        tre = new JButton("3");
        CE = new JButton("CE");
        quattro = new JButton("4");
        cinque = new JButton("5");
        sei = new JButton("6");
        piu = new JButton("+");
        sette = new JButton("7");
        otto = new JButton("8");
        nove = new JButton("9");
        meno = new JButton("-");
        per = new JButton("*");
        zero = new JButton("0");
        diviso = new JButton(":");
        uguale = new JButton("=");

        panel2.add(uno);
        panel2.add(due);
        panel2.add(tre);
        panel2.add(CE);
        panel2.add(quattro);
        panel2.add(cinque);
        panel2.add(sei);
        panel2.add(piu);
        panel2.add(sette);
        panel2.add(otto);
        panel2.add(nove);
        panel2.add(meno);
        panel2.add(per);
        panel2.add(zero);
        panel2.add(diviso);
        panel2.add(uguale);

        add(panel2);

        setVisible(true);

    }

    public static void main(String[] args) {
        new CalcolatriceMia();
    }
}
