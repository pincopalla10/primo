package CalcoloCodiceFiscale;

import javax.swing.*;
import java.awt.*;

public class CalcoloCodiceFiscale extends JFrame {

    JTextField textField1;
    JTextField textField2;
    JRadioButton radioButton1;
    JRadioButton radioButton2;
    JTextField giornotTextField;
    JComboBox<String> meseComboBox;
    JTextField annoTextField;
    JTextField siglaComune;
    JLabel risultato;
    String mesi[] = { "", "Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre",
            "Ottobre", "Novembre", "Dicembre" };

    public CalcoloCodiceFiscale() {

        setTitle("Calcolo Codcice Fiscale");
        setSize(300, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new GridLayout(8, 1));

        /* titolo */
        JPanel panel1 = new JPanel();
        JLabel label1 = new JLabel("Calcolo Codice Fiscale");
        panel1.add(label1);
        add(panel1);

        /* Cognome */
        JPanel panel2 = new JPanel();
        JLabel cognome = new JLabel("Cognome ", SwingConstants.LEFT);
        textField1 = new JTextField(15);
        panel2.add(cognome);
        panel2.add(textField1);
        add(panel2);

        /* Nome */
        JPanel panel3 = new JPanel();
        JLabel nome = new JLabel("Nome ", SwingConstants.LEFT);
        textField2 = new JTextField(15);
        panel3.add(nome);
        panel3.add(textField2);
        add(panel3);

        /* Sesso */
        JPanel panel4 = new JPanel();
        JLabel sesso = new JLabel("Sesso ", SwingConstants.LEFT);
        panel4.add(sesso);
        radioButton1 = new JRadioButton("Maschio");
        radioButton2 = new JRadioButton("Femmina");
        ButtonGroup group = new ButtonGroup();
        group.add(radioButton1);
        group.add(radioButton2);
        panel4.add(radioButton1);
        panel4.add(radioButton2);
        add(panel4);

        /* Data */
        JPanel panel5 = new JPanel();
        JLabel data = new JLabel("Data ", SwingConstants.LEFT);
        panel5.add(data);
        giornotTextField = new JTextField(2);
        panel5.add(giornotTextField);
        meseComboBox = new JComboBox<String>(mesi);
        panel5.add(meseComboBox);
        annoTextField = new JTextField(4);
        panel5.add(annoTextField);
        add(panel5);

        /* Comune */
        JPanel panel6 = new JPanel();
        JLabel comune = new JLabel("Comune ", SwingConstants.LEFT);
        panel6.add(comune);
        siglaComune = new JTextField(15);
        panel6.add(siglaComune);
        add(panel6);

        /* Bottone Calcola */
        JPanel panel7 = new JPanel();
        JButton calcola = new JButton("Calcola Codice Fiscale");
        panel7.add(calcola);
        add(panel7);

        /* Risultato del calcolo */
        JPanel panel8 = new JPanel();
        risultato = new JLabel();
        panel8.add(risultato);
        add(panel8);

        setVisible(true);
    }// CalcoloCodiceFiscale

    public static void main(String[] args) {
        new CalcoloCodiceFiscale();
    }// main
}// CalcoloCodiceFiscale
