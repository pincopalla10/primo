package AreaRettangolo;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.*;

public class AreaRettangolo extends JFrame implements ActionListener {

    JTextField basTextField, altezzField, risuAField, risuPField;
    JButton bottoneCalcola, bottoneAzzera;

    public AreaRettangolo() {

        setTitle("Area Rettangolo");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 1));

        /* base */
        JPanel panel1 = new JPanel();
        JLabel base = new JLabel("Lunghezza della base ");
        basTextField = new JTextField(15);
        panel1.add(base);
        panel1.add(basTextField);
        add(panel1);

        /* altezza */
        JPanel panel2 = new JPanel();
        JLabel altezza = new JLabel("Lunghezza dell'altezza ");
        altezzField = new JTextField(15);
        panel2.add(altezza);
        panel2.add(altezzField);
        add(panel2);

        /* bottone calcola e azzera (prendere spunto da calcolatrice IMC) */
        JPanel panel3 = new JPanel();
        bottoneCalcola = new JButton("Calcola");
        bottoneAzzera = new JButton("Azzera");
        panel3.add(bottoneCalcola);
        panel3.add(bottoneAzzera);
        bottoneCalcola.addActionListener(this);
        bottoneAzzera.addActionListener(this);
        add(panel3);

        /* risultato */
        JPanel panel4 = new JPanel();
        JLabel risuLabel = new JLabel("Misura dell'area ");
        JLabel risuLabel2 = new JLabel("Misura del perimetro");
        risuPField = new JTextField(15);
        risuAField = new JTextField(15);
        panel4.add(risuLabel);
        panel4.add(risuAField);
        panel4.add(risuLabel2);
        panel4.add(risuPField);
        risuAField.setEditable(false);
        risuPField.setEditable(false);
        add(panel4);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("Calcola")) {
            risuAField.setText(String.format("%.2f", calcoloArea()));
            risuPField.setText(String.format("%.2f", calcoloPerimetro()));
        } else if (e.getActionCommand().equals("Azzera")) {
            basTextField.setText("");
            altezzField.setText("");
            risuAField.setText("");
            risuPField.setText("");

        }
    }

    public double calcoloArea() {
        double bas = Double.parseDouble(basTextField.getText());
        double alt = Double.parseDouble(altezzField.getText());
        double area;
        area = bas * alt;
        return area;

    }

    public double calcoloPerimetro() {
        double bas = Double.parseDouble(basTextField.getText());
        double alt = Double.parseDouble(altezzField.getText());
        double perimetro;
        perimetro = (bas * 2) + (alt * 2);
        return perimetro;
    }

    public static void main(String[] args) {
        new AreaRettangolo();
    }
}
