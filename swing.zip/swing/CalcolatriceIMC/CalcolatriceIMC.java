import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalcolatriceIMC extends JFrame {

    JTextField textField1;
    JTextField textField2;
    JRadioButton radioButton1;
    JRadioButton radioButton2;
    JLabel resultLabel;

    public CalcolatriceIMC() {
        setTitle("Calcolatrice IMC");
        setSize(300, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new GridLayout(6, 1));

        /* Titolo della calcolatrice */
        JPanel panel1 = new JPanel();
        JLabel label1 = new JLabel("Calcolatrice IMC");
        panel1.add(label1);
        add(panel1);

        /* Peso e Altezza */
        JPanel panel2 = new JPanel();
        JLabel altezza = new JLabel("Altezza: ");
        textField1 = new JTextField(15);
        panel2.add(altezza);
        panel2.add(textField1);
        add(panel2);
        JPanel panel3 = new JPanel();
        JLabel peso = new JLabel("Peso: ");
        textField2 = new JTextField(15);
        panel3.add(peso);
        panel3.add(textField2);
        add(panel3);

        /* RadioButton scelta centimetri o metri */
        JPanel panel4 = new JPanel();
        radioButton1 = new JRadioButton("Centimetri");
        radioButton2 = new JRadioButton("Metri");
        ButtonGroup group = new ButtonGroup();
        group.add(radioButton1);
        group.add(radioButton2);

        panel4.add(radioButton1);
        panel4.add(radioButton2);
        add(panel4);

        /* Bottone Calcola e Bottone Azzera */
        JPanel panel5 = new JPanel();
        JButton button1 = new JButton("Calcola");
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double peso = Double.parseDouble(textField2.getText());
                double altezza = Double.parseDouble(textField1.getText());
                double imc;

                if (radioButton1.isSelected()) {
                    // Altezza in centimetri
                    altezza = altezza / 100;
                }

                imc = peso / Math.pow(altezza, 2);
                resultLabel.setText("Il tuo IMC e': " + imc);
            }// actionPerformed
        });

        JButton button2 = new JButton("Azzera");
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textField1.setText("");
                textField2.setText("");
                resultLabel.setText("");
            }// actionePerformed
        });

        panel5.add(button1);
        panel5.add(button2);
        add(panel5);

        /* Risultato */
        JPanel panel6 = new JPanel();
        resultLabel = new JLabel();
        panel6.add(resultLabel);
        add(panel6);

        setVisible(true);
    }// CalcolatriceIMC

    public static void main(String[] args) {
        new CalcolatriceIMC();
    }// main
}// CalcolatriceIMC